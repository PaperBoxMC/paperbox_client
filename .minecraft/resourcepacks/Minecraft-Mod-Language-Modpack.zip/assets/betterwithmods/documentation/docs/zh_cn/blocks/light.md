![Light Block](block:betterwithmods:light)

一个可以用红石信号控制的光源,这是唯一能够让[大麻](hemp.md)不需要阳光照射仍可生长的办法